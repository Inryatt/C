For a complete installation run:

./install.sh

